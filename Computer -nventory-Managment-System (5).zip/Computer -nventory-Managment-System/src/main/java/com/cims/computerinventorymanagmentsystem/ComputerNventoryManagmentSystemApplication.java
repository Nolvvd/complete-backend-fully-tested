package com.cims.computerinventorymanagmentsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComputerNventoryManagmentSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(ComputerNventoryManagmentSystemApplication.class, args);
    }

}
