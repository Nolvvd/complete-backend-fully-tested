package com.cims.computerinventorymanagmentsystem.model;

public enum Role {
    STANDARDUSER,
    ADMIN
}
