package com.cims.computerinventorymanagmentsystem.exceptions;

public class MaintenanceNotFoundException extends RuntimeException {
    public MaintenanceNotFoundException(String message) {
        super(message);
    }
}
